#配置python开发环境
***
**下载python** 
点击链接下载最新版        [python官网](https://www.python.org/ "python")

**运行python**
在开始菜单中找到 python IDLE
![Alt text](./_[0W3}HX0A[V1{94ZJX`BFN.png)

至此就完成了python开发环境的配置。
